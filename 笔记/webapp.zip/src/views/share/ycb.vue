<template>
  <div class="ycb-box">
    <h3 class="h3tit">目前主要有以下两种途径获得易车币：</h3>
    <h6 class="h6tit">一、完成每日/每月易车伙伴内的日常任务，任务列表如下：</h6>
    <h6 class="h6tit">每日任务</h6>
    <p>
      <span class="primary">签到：</span>每天奖励2枚易车币；连续签到大于3天，每天奖励5枚易车币。连续签到中断后开始重新计数。 </p>
    <p>
      <span class="primary">打卡：</span>易车学院打卡每天奖励1枚易车币；连续打卡大于3天，每天奖励3枚易车币。连续打卡中断后开始重新计数。 </p>
    <p>
      <span class="primary">评价：</span>易车学院每门课程首次评价奖励50易车币。 </p>
    <p>
      <span class="primary">发布车动态：</span>发布一条车动态，奖励3枚易车币，每天最多奖励3次。 </p>
    <p>
      <span class="primary">线索建卡：</span>会话线索或手机线索成功建卡，奖励5枚易车币，每天最多奖励3次。 </p>
    <p>
      <span class="primary">扫码建卡：</span>线下客户通过扫描二维码成功建卡，奖励1枚易车币，每天最多奖励1次。 </p>
    <p>
      <span class="primary">客户5星评价：</span>IM/扫码获1次5星评价，奖励1枚易车币，每天最多奖励1次。 </p>
    <h6 class="h6tit">每月任务</h6>
    <p> 销售业绩审核通过：每上传并审核通过一条销售业绩，奖励30枚易车币，每月最多奖励20次。 </p>
    <h6 class="h6tit">二、易车伙伴会不定期发布各种活动，参加活动有机会获得数额不等的易车币奖励。</h6>
  </div>
</template>
<script type="text/javascript">(function(){var b=document.createElement("meta");b.setAttribute("name","viewport");var c=window.devicePixelRatio,a=c?1/c:1;window.screen.availWidth==document.documentElement.offsetWidth&&(c=a=1);document.documentElement.setAttribute("data-dpr",c||1);window.navigator.userAgent.match(/android/i)?b.setAttribute("content","width=device-width, initial-scale="+a+", maximum-scale="+a+", minimum-scale="+a+", user-scalable=no"):b.setAttribute("content","initial-scale="+a+", maximum-scale="+a+", minimum-scale="+a+", user-scalable=no");document.head.appendChild(b)})();</script>
<script type="text/javascript">var dpr=document.documentElement.getAttribute("data-dpr")||1,width=document.documentElement.offsetWidth,fontSize=100/750*width;document.querySelector("html").style.fontSize=fontSize+"px";window.addEventListener("resize",function(){var a=100/750*document.querySelector("html").offsetWidth;document.querySelector("html").style.fontSize=a+"px"});</script>
<!-- 别格式化，有问题 -->

<script>
export default {
  name: 'ycb'
}
</script>

<style scoped>
@import "~@/assets/css/modules/ycb.min.css";
</style>