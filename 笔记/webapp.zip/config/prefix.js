import env from './env'

export default `'${env.BASE_URL}'`