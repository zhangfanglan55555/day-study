import env from "./env";

export default `'${env.HOSTS}'`
